Hi folks...

This is a little demo that loads a Milkshape-Model and renders it using OpenGl. 
It's coded in Borland Delphi and the source is included. The loader support's
everything that is contained in an ms3d-file: Animation, Materials, Textures, Groups etc...

If you have never heard of Milkshape you've missed a great low-cost Moddeling-Software. Check
the authors website: http://www.swissquake.ch/chumbalum-soft

My code is based on a Tutorial for C++ made by Brett Porter (brettporter@yahoo.com) and the 
Milkshape SDK.
If you want to learn more check Bretts website: http://rsn.gamedev.net

Note that the included model is not made by me!
The original Author is Bart Secker. (bartsick@yahoo.com) And I don't even know if it's okay
with him that I use it. :)
But Brett Porter included it in his ms3d-anim demo and since my code is more or less a conversion
of his I use it, too. (I will replace it as soon as I've a self-made model - but this could
take a while)

	
HAPPY CODING!
	Lithander (lithander@gmx.de)

